#include <stdio.h>
int main() {
	int nota;
	printf(" Inserte una nota: "); scanf("%d",&nota);
	switch(nota) {
	case 0: printf("\nSuspenso"); break;
	case 1: printf("\nSuspenso"); break;
	case 2: printf("\nSuspenso"); break;
	case 3: printf("\nSuspenso"); break;
	case 4: printf("\nSuspenso"); break;
	case 5: printf("\nAprobado"); break;
	case 6: printf("\nBien"); break;
	case 7: printf("\nNotable"); break;
	case 8: printf("\nNotable"); break;
	case 9: printf("\nSobresaliente"); break;
	case 10: printf("\nSobresaliente"); break;
	default: printf("esa nota es incorrecta");
	}
	return 0;
}
