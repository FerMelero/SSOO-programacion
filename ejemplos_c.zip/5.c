int main () {
	char c;
	c=97; /* el valor en decimal del código ASCII*/
	c='a'; /* el carácter entre comillas*/
	c=0x61; /* el valor en hexadecimal del código ASCII*/
	c=0141; /* el valor en octal del código ASCII*/
	return 0;
}
