#include <stdio.h>
int main( )
{
	int multiplicador; /*se define multiplicador como un entero */
	int multiplicando; /*se define multiplicando como un entero */
	int res; /*se define resultado como un entero*/
	multiplicador = 1000; /*se asignan valores*/
	multiplicando=2;
	res=multiplicador*multiplicando;
	printf("Resultado =%d\n",res); /*se muestra el resultado */
	return 0;
}
