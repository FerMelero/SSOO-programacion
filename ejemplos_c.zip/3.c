#include <stdio.h>
int main( ) {
	int multiplicador, multiplicando; /*se definen 2 variables*/
	multiplicador =1000; /*se les asigna valor*/
	multiplicando=2;
	printf("Resultado = %d\n", multiplicador*multiplicando);
	/*se muestra el resultado por pantalla*/
	return 0;
}
