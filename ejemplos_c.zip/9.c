#include <stdio.h>
int main () {
	int i;
	float x;
	printf(" teclee el número entero i ");
	scanf("%d", &i);
	printf(" teclee el número real x ");
	scanf("%f", &x);
	return 0;
}
